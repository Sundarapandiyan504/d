'use strict';

/**
 * badbank controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::badbank.badbank');
