'use strict';

/**
 * show controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::show.show');
